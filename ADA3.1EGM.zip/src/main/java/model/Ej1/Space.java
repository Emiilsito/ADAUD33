package model.Ej1;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

@Entity
@Table(name = "spaces")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Space {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private boolean active;

    @Column(nullable = false)
    private int capacity;

    @Column(nullable = false, length = 60, unique = true)
    private String code;

    @Column(precision = 10, scale = 2)
    private BigDecimal hourlyPrice;

    @Column(length = 150, nullable = false)
    private String name;

    public enum SpaceType {
        MEETING_ROOM,
        OPEN_DESK,
        PRIVATE_OFFICE
    }


    @Enumerated(EnumType.STRING)
    private SpaceType type;

    @ManyToOne
    @JoinColumn(name = "venue_id", nullable = false)
    private Venue venue;

    @ManyToMany
    @JoinTable(
            name = "space_tag",
            joinColumns = @JoinColumn(name = "space_id"),
            inverseJoinColumns = @JoinColumn(name = "tag_id"),
            uniqueConstraints = @UniqueConstraint(columnNames = {"space_id", "tag_id"})
    )
    private List<Tag> tags;

    // N:M con model.Ej1.User a través de model.Ej1.Booking
    @OneToMany(mappedBy = "space", cascade = CascadeType.ALL)
    private List<Booking> bookings;

}
