import org.hibernate.Session;

public class Main {
    public static void main(String[] args) {
        HibernateUtil.getSessionFactory();
    }
}
