package com.example.Ej1.dao;

import com.example.Ej1.domain.Space;

public interface SpaceDao extends GenericDao<Space, Long>{
}
