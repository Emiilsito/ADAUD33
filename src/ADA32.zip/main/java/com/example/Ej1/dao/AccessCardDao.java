package com.example.Ej1.dao;

import com.example.Ej1.domain.AccessCard;

public interface AccessCardDao extends GenericDao<AccessCard, Long>{
}
