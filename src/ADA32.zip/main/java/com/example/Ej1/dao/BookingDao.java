package com.example.Ej1.dao;

import com.example.Ej1.domain.Booking;

public interface BookingDao extends GenericDao<Booking, Long>{
}
