package com.example.Ej1.dao;

import com.example.Ej1.domain.Venue;

public interface VenueDao extends GenericDao<Venue, Long>{
}
