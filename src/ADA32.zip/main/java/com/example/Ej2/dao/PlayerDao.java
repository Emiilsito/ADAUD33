package com.example.Ej2.dao;

import com.example.Ej1.dao.GenericDao;
import com.example.Ej2.domain.Player;

public interface PlayerDao extends GenericDao<Player, Long> {
}
