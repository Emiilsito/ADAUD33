package com.example.Ej2.dao;

import com.example.Ej1.dao.GenericDao;
import com.example.Ej2.domain.RfidCard;

public interface RfidCardDao extends GenericDao<RfidCard, Long> {
}
